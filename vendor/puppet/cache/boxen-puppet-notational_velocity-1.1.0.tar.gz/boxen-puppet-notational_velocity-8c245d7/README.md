# Notational Velocity Puppet Module for Boxen

## Usage

```puppet
include notational_velocity
```

Or use the [nvalt fork](http://brettterpstra.com/projects/nvalt) instead:

```puppet
include notational_velocity::nvalt
```

## Required Puppet Modules

* boxen
* stdlib
